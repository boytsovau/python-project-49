### Hexlet tests and linter status:
[![Actions Status](https://github.com/boytsovau/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/boytsovau/python-project-49/actions)


<a href="https://codeclimate.com/github/boytsovau/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1b5c5089f32a03734b29/maintainability" /></a>