#!/usr/bin/env python3

def brain_games():
    print("Welcome to the Brain Games!")

if __name__ == '__main__':
    brain_games()